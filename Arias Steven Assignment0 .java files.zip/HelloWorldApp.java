/**
 * The HelloWorldApp class implements an application that
 * displays "Hello World!" to the standard output.
 */
public class HelloWorldApp {
	public static void main(	String[] args) {
		// Display "Hello World!"
		System.out.println("Hello World!");
	}
}
