public class MyFirstClass {

	public static void main(String[] args) {
		System.out.println("This is my first program!");
		
	}

}
