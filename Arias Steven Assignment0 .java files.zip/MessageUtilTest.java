import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MessageUtilTest {

	@Test
	void testPrintMessage() {
		fail("Not yet implemented");
	}

}
